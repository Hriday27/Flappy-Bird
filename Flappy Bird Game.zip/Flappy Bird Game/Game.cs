﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Flappy_Bird_Game
{
    public partial class Game : Form
    {

        //Out
        bool lose = false;
        //Bird Vars
        int gravity = 5;
        int velocity = 0;
        int upforce = 50;
        Point coord = new Point(80, 200);

        //pilalr vars
        int pspeed = 10;

        public Game()
        {
            InitializeComponent();
        }

        void Collision()
        {
            //check vertical collisions
            if(Bird.Location.X == pillarTop.Location.X && Bird.Location.Y <= pillarTop.Height)
            {
                this.Close();
                lose = true;
            }
            if (Bird.Location.X == pillarBot.Location.X && Bird.Location.Y <= pillarBot.Height)
            {
                this.Close();
                lose = true;
            }

            //check horizontal collisions
            if (Bird.Location.X <= pillarTop.Width && Bird.Location.Y == pillarTop.Location.Y)
            {
                this.Close();
                lose = true;
            }
            if (Bird.Location.X <= pillarBot.Width && Bird.Location.Y == pillarBot.Location.Y)
            {
                this.Close();
                lose = true;
            }
        }

        private void tmrBird_Tick(object sender, EventArgs e)
        {
            Bird.Location = coord;
            coord.Y += gravity;
            gravity += velocity;

            if(velocity >= 4)
            {
                velocity = 0;
                gravity = 0;
            }
        }

        private void Game_Load(object sender, EventArgs e)
        {
            Out.SendToBack();
            tmrBird.Start();
            tmrOut.Start();
            tmrPillar.Start();
        }

        private void Game_KeyPress(object sender, KeyPressEventArgs e)
        {
            coord.Y -= upforce;
        }

        private void tmrPillar_Tick(object sender, EventArgs e)
        {
            Random r1 = new Random();
            Random r2 = new Random();

            int height1 = r1.Next(140, 197);
            int height2 = r2.Next(200, 282);

            pillarTop.Left -= pspeed;
            pillarBot.Left -= pspeed;


            //Spawn Pillar
            if(pillarTop.Left < -50)
            {
                pillarTop.Left = 200;
                pillarTop.Height = height1;
            }

            if (pillarBot.Left < -50)
            {
                pillarBot.Left = 200;
                pillarBot.Height = height2;
            }


        }

        private void tmrOut_Tick(object sender, EventArgs e)
        {
            Collision();
            if(lose == true)
            {
                tmrOut.Stop();
                tmrPillar.Stop();
                tmrBird.Stop();
                Out.BringToFront();
            }
            if(Bird.Location.Y >= Ground.Location.Y)
            {
                tmrOut.Stop();
                tmrPillar.Stop();
                tmrBird.Stop();
                this.Close();
            }
        }
    }
}
