﻿namespace Flappy_Bird_Game
{
    partial class Game
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Bird = new System.Windows.Forms.PictureBox();
            this.pillarTop = new System.Windows.Forms.PictureBox();
            this.pillarBot = new System.Windows.Forms.PictureBox();
            this.tmrBird = new System.Windows.Forms.Timer(this.components);
            this.tmrPillar = new System.Windows.Forms.Timer(this.components);
            this.tmrOut = new System.Windows.Forms.Timer(this.components);
            this.Ground = new System.Windows.Forms.Panel();
            this.Out = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.Bird)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pillarTop)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pillarBot)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // Bird
            // 
            this.Bird.BackColor = System.Drawing.Color.Transparent;
            this.Bird.Image = global::Flappy_Bird_Game.Properties.Resources.Bird;
            this.Bird.Location = new System.Drawing.Point(183, 160);
            this.Bird.Name = "Bird";
            this.Bird.Size = new System.Drawing.Size(70, 61);
            this.Bird.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Bird.TabIndex = 0;
            this.Bird.TabStop = false;
            // 
            // pillarTop
            // 
            this.pillarTop.BackColor = System.Drawing.Color.Transparent;
            this.pillarTop.Image = global::Flappy_Bird_Game.Properties.Resources.Pillar;
            this.pillarTop.Location = new System.Drawing.Point(352, 0);
            this.pillarTop.Name = "pillarTop";
            this.pillarTop.Size = new System.Drawing.Size(75, 197);
            this.pillarTop.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pillarTop.TabIndex = 1;
            this.pillarTop.TabStop = false;
            // 
            // pillarBot
            // 
            this.pillarBot.BackColor = System.Drawing.Color.Transparent;
            this.pillarBot.Image = global::Flappy_Bird_Game.Properties.Resources.Pillar;
            this.pillarBot.Location = new System.Drawing.Point(352, 316);
            this.pillarBot.Name = "pillarBot";
            this.pillarBot.Size = new System.Drawing.Size(75, 282);
            this.pillarBot.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pillarBot.TabIndex = 2;
            this.pillarBot.TabStop = false;
            // 
            // tmrBird
            // 
            this.tmrBird.Tick += new System.EventHandler(this.tmrBird_Tick);
            // 
            // tmrPillar
            // 
            this.tmrPillar.Tick += new System.EventHandler(this.tmrPillar_Tick);
            // 
            // tmrOut
            // 
            this.tmrOut.Interval = 1;
            this.tmrOut.Tick += new System.EventHandler(this.tmrOut_Tick);
            // 
            // Ground
            // 
            this.Ground.BackColor = System.Drawing.Color.Yellow;
            this.Ground.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.Ground.Location = new System.Drawing.Point(0, 604);
            this.Ground.Name = "Ground";
            this.Ground.Size = new System.Drawing.Size(550, 47);
            this.Ground.TabIndex = 3;
            // 
            // Out
            // 
            this.Out.AutoSize = true;
            this.Out.BackColor = System.Drawing.Color.Transparent;
            this.Out.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Out.Location = new System.Drawing.Point(55, 44);
            this.Out.Name = "Out";
            this.Out.Size = new System.Drawing.Size(184, 37);
            this.Out.TabIndex = 4;
            this.Out.Text = "You are out";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = global::Flappy_Bird_Game.Properties.Resources.background;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(550, 651);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // Game
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = global::Flappy_Bird_Game.Properties.Resources.background;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(550, 651);
            this.Controls.Add(this.Out);
            this.Controls.Add(this.Ground);
            this.Controls.Add(this.pillarBot);
            this.Controls.Add(this.pillarTop);
            this.Controls.Add(this.Bird);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Game";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Game";
            this.Load += new System.EventHandler(this.Game_Load);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Game_KeyPress);
            ((System.ComponentModel.ISupportInitialize)(this.Bird)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pillarTop)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pillarBot)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox Bird;
        private System.Windows.Forms.PictureBox pillarTop;
        private System.Windows.Forms.PictureBox pillarBot;
        private System.Windows.Forms.Timer tmrBird;
        private System.Windows.Forms.Timer tmrPillar;
        private System.Windows.Forms.Timer tmrOut;
        private System.Windows.Forms.Panel Ground;
        private System.Windows.Forms.Label Out;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

